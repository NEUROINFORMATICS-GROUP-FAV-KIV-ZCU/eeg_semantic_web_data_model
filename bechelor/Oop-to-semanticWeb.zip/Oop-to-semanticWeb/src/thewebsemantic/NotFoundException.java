package thewebsemantic;

/**
 * It represents an exception in case when loaded class gathered by param
 * can not be found.
 * 
 */
public class NotFoundException extends RuntimeException {}
