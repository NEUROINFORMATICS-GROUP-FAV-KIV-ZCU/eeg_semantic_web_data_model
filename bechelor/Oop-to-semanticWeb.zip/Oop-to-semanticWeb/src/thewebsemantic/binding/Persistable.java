package thewebsemantic.binding;

public interface Persistable {
	
	public void activate();

}
