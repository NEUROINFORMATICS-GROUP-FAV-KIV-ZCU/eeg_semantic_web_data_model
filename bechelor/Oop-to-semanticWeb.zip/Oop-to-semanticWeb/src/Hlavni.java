
import java.io.IOException;





/**
 * Třída, která plní funkci "dalšího programu". V této třída se zavolá celej projekt pomocí
 * konstruktoru
 *
 * @author Dominik Šmíd
 */
public class Hlavni {

    public static void main(String[] args) {

         new OOMtoSemanticWeb();
    }
}
