package cz.zcu.kiv.annotations.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.table.TableCellRenderer;

/**
 * Renderer for JLabel included in JTable with attributes of class of
 * edited class
 *
 * @author Filip Markvart
 */
public class TableLabelRenderer implements TableCellRenderer{

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

        if (isSelected) {
            ((JLabel)value).setForeground(Color.red);
            
        }else{
            ((JLabel)value).setForeground(Color.black);
        }

        if (hasFocus) {
            ((JLabel)value).setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        }else{
            ((JLabel)value).setBorder(BorderFactory.createEmptyBorder());
        }

        JPanel subPanel = new JPanel(new BorderLayout());
        subPanel.setBorder(BorderFactory.createMatteBorder(0, 2, 0, 0, subPanel.getBackground()));
        subPanel.add((JLabel)value, BorderLayout.CENTER);

        if (((JLabel)value).getText().equals("Class")){
            subPanel.setBackground(new Color(202, 202, 202));
            subPanel.setBorder(BorderFactory.createMatteBorder(0, 2, 0, 0, new Color(202, 202, 202)));
        }

        return subPanel;
    }

}
