package cz.zcu.kiv.annotations.application;

import japa.parser.ParseException;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;
import cz.zcu.kiv.annotations.data.Attribute;
import cz.zcu.kiv.annotations.data.Iattribute;
import japa.parser.JavaParser;
import japa.parser.TokenMgrError;
import japa.parser.ast.CompilationUnit;
import japa.parser.ast.body.FieldDeclaration;
import japa.parser.ast.visitor.VoidVisitorAdapter;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Iterator;


/**
 * This class uses reflection to gather atributes of classes stored in
 * defined package and creates Attribute structure which contains all
 * classes attributes with them annotations
 *
 *
 * @author Filip Markvart
 */
public class AttributeCreator {


    /**
     * Method returns List of Attribute for selected class using reflection
     * to get attributes names a AttrAnnotationCreator to get all possible
     * annotations for each attribute
     *
     * @param className String name of the class
     * @param packageName String name of the package
     * @return List of Attribute
     * @throws Exception Reflection problem exception
     */                                                                               //ini File
    public List<Iattribute> getAttributes(String className, String packageName, String classAnnotIniFile, boolean sources) throws FileNotFoundException, NoClassDefFoundError, ClassFormatError, Exception, TokenMgrError {

        IannotationCreator attrAnnotationCreator = new AttrAnnotationCreator();

        List<Iattribute> attributes = new ArrayList<Iattribute>();

        Iattribute attribute;

        if (sources){

            for(String attrName: getClassesAtributes(className)) {

                attribute = new Attribute(attrName, attrAnnotationCreator.getAnnotations(classAnnotIniFile));
                attributes.add(attribute);
            }

        }else{

            for(String attrName: getClassesAtributes(className, packageName)) {

                attribute = new Attribute(attrName, attrAnnotationCreator.getAnnotations(classAnnotIniFile));
                attributes.add(attribute);
            }
        }

        return attributes;
    }


    /**
     * Method uses reflection to gather classes atributes from
     * selected class saved in selected package and returns List of
     * String name represented attributes
     *
     * @param className Target class name
     * @param packageName Name of the containing package
     * @return List with Strng atributes names
     */
    private List<String> getClassesAtributes(String className, String packageName) throws ClassFormatError, Exception, NoClassDefFoundError {

        List attrNames = new ArrayList<String>();

        File directory = new File(Constants.ROOT_PATH);

        URL url = directory.toURI().toURL();
	URL[] urls = new URL[] { url };

	ClassLoader classLoader = new URLClassLoader(urls);

        String dataPathClass = className;

        if (packageName.length() != 0) {

            dataPathClass = packageName + "." + className;
        }

	Class targetClass = classLoader.loadClass(dataPathClass);

        Field fieldNames[] = targetClass.getDeclaredFields();

        for (int i = 0; i < fieldNames.length; i++) {

            attrNames.add(fieldNames[i].getName());
        }

        return attrNames;
    }


    /**
     * Method uses Java parser library to gather source classes atributes from
     * selected class saved in selected package and returns List of
     * String name represented attributes
     *
     * @param className Target class name
     * @return List with String atributes names
     */
    private List<String> getClassesAtributes(String className) throws FileNotFoundException, ParseException, IOException, Exception, TokenMgrError {

        File target = new File(Constants.ROOT_PATH + "/" + Constants.SOURCES + "/" + className + ".java");

        FileInputStream in = new FileInputStream(target);

        CompilationUnit cu;

        cu = JavaParser.parse(in);
        MethodVisitor mv = new MethodVisitor();
        mv.visit(cu, null);

        List<String> result = mv.getAttrs();

        in.close();

        return result;

    }

    private class MethodVisitor extends VoidVisitorAdapter {

        private List attrNames;

        public MethodVisitor() {

            attrNames = new ArrayList<String>();
        }

        @Override
        public void visit(FieldDeclaration n, Object arg) {

            attrNames.add(n.getVariables().get(0).getId().getName());
        }

        public List<String> getAttrs(){


            return attrNames;

        }

    }
}
