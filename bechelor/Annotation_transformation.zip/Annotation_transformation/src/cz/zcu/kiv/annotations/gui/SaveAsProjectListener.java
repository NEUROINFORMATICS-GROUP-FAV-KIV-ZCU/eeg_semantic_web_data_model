package cz.zcu.kiv.annotations.gui;

import cz.zcu.kiv.annotations.application.IprojectManager;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.JOptionPane;

/**
 * Jmenu item Save project listener class is used to save actual
 * project data and user annotations to one project file and save
 * it on disk.
 *
 * @author Filip Markvart
 */
public class SaveAsProjectListener implements ActionListener{


    private Frame mainWindow;
    private IprojectManager project;


     public SaveAsProjectListener(IprojectManager project, Frame mainWindow) {

        this.mainWindow = mainWindow;
        this.project = project;
    }

    /**
     * Gather user created annotations and save this data to file.
     * The annotation file and all project classes are ziped to one
     * file and seved to disk.
     *
     * @param e
     */
    public void actionPerformed(ActionEvent e) {

        File projectFile;

        if ((projectFile = getFileName()) != null) {

            if (project.saveProject(projectFile)) {
                AppStatus.savedFileName = projectFile;
                 AppStatus.subItemSaveProject.setEnabled(true);
            }else {
                JOptionPane.showMessageDialog(mainWindow, "Can not save project.");
            }
        }
    }


    /**
     * Method creates a dialog asking to user to saving project name file.
     *
     * @return Name of the file with path
     */
    public File getFileName() {

        JFileChooser fileChooser = new JFileChooser();

        fileChooser.setMultiSelectionEnabled(false);
        fileChooser.setAcceptAllFileFilterUsed(true);
        fileChooser.setFileFilter(new SelectedFilter("apf"));

            if ((fileChooser.showDialog(mainWindow, "Select file") == 0)) {

                if (fileChooser.getSelectedFile().exists()) {

                    int stat = JOptionPane.showConfirmDialog(mainWindow, "File already exists, overwrite it?");
                    
                    if (stat == 0){
                        return fileChooser.getSelectedFile();
                    }else {

                        return null;
                    }
                }


                return fileChooser.getSelectedFile();

            }else {
              return null;
            }
    }

    /**
     * File filter defines the selected file format
     * of structure to save file
     */
    public class SelectedFilter extends FileFilter {

        String suffix;

        private SelectedFilter(String type) {

            suffix = type;
        }

	@Override
	public boolean accept(File f) {

            if (f.isDirectory()) return true;
            if (f.getName().contains(suffix) || f.getName().contains(suffix.toUpperCase())) {

                return true;
            }else {
                return false;
            }
        }

	@Override
	public String getDescription() {

            return suffix;
	}
    }
}