package cz.zcu.kiv.annotations.gui;

import cz.zcu.kiv.annotations.application.IprojectManager;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFileChooser;

/**
 * This listener call project method to export annotated classes
 *
 * @author Filip Markvart
 */
public class ExportClassesListener implements ActionListener{

    private Frame mainWindow;
    private IprojectManager project;

    public ExportClassesListener(IprojectManager project, Frame mainWindow) {

        this.mainWindow = mainWindow;
        this.project = project;
    }


    public void actionPerformed(ActionEvent e) {

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        if ((fileChooser.showDialog(mainWindow, "Select target") == 0)) {

            project.exportClasses(fileChooser.getSelectedFile());
                    
        }else {
            return;
        }
    }

}
