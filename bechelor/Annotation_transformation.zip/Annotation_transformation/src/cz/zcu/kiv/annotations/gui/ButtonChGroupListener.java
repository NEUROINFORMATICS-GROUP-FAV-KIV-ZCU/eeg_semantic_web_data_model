package cz.zcu.kiv.annotations.gui;

import cz.zcu.kiv.annotations.application.IprojectManager;
import cz.zcu.kiv.annotations.gui.DisplayProjectData.TableActionListener;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * Listener class for group changes of attributes button
 *
 * @author Filda Markvart
 */
public class ButtonChGroupListener implements ActionListener{

    private List<String[]> selectedAttrs;
    private IprojectManager project;
    private TableActionListener ListenerDiffs;

    public ButtonChGroupListener(IprojectManager project, List<String[]> selectedAttrs, TableActionListener ListenerDiffs){

        this.selectedAttrs = selectedAttrs;
        this.project = project;
        this.ListenerDiffs = ListenerDiffs;
    }

    public void actionPerformed(ActionEvent e) {

        if (selectedAttrs.isEmpty()) {

            JOptionPane.showMessageDialog(new Frame(), "Nothing is selected");
            return;
        }

        new DisplayAnnotations(project, selectedAttrs, ListenerDiffs);

    }
}
