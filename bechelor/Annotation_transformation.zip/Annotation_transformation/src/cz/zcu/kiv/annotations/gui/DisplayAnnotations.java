package cz.zcu.kiv.annotations.gui;

import cz.zcu.kiv.annotations.application.IprojectManager;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import cz.zcu.kiv.annotations.application.ProjectManager;
import cz.zcu.kiv.annotations.data.Iannotation;
import cz.zcu.kiv.annotations.gui.DisplayProjectData.TableActionListener;
import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.JScrollPane;

/**
 *
 * @author Filip Markvart
 */
public class DisplayAnnotations extends JFrame{

    private IprojectManager project;
    private Frame frame;
    private List<Object[]> guiItems;
    
    private String classAnnotName;
    private String attrAnnotName;

    private boolean groupChange;

    private List<String[]> selectedAttrs;

    private TableActionListener ListenerDiffs;

    public DisplayAnnotations(IprojectManager project, List<Iannotation> annotations, String className, String attrName, TableActionListener ListenerDiffs){

        this.frame = this;
        this.guiItems = new ArrayList<Object[]>();
        this.project = project;

        this.classAnnotName = className;
        this.attrAnnotName = attrName;
        this.groupChange = false;

        this.setLayout(new BorderLayout());

        this.ListenerDiffs = ListenerDiffs;
    
    this.add(createAnnotPanel(annotations), BorderLayout.CENTER);
    this.add(createButtonsPanel(), BorderLayout.SOUTH);

    this.setTitle("Anotation change: " + className);

    if (attrName != null) {
        this.setTitle("Anotation change: " + className+ ": " + attrName);
    }

    this.setVisible(true);
    this.setBounds(400, 100, 400, 400);
    
    }

    public DisplayAnnotations(IprojectManager project, List<String[]> selectedAttrs, TableActionListener ListenerDiffs){ //group change

        this.frame = this;
        this.guiItems = new ArrayList<Object[]>();
        this.project = project;

        this.groupChange = true;

        this.ListenerDiffs = ListenerDiffs;
        this.classAnnotName = selectedAttrs.get(0)[0];
        this.setLayout(new BorderLayout());

        this.selectedAttrs = selectedAttrs;

        if (selectedAttrs.get(0)[1] != null) {
            this.attrAnnotName = selectedAttrs.get(0)[1];
            this.add(createAnnotPanel(project.getClassesAttrAnnotations(classAnnotName, attrAnnotName)), BorderLayout.CENTER);
        }else {
            this.add(createAnnotPanel(project.getClassesAnnotations(classAnnotName)), BorderLayout.CENTER);
        }

        this.add(createButtonsPanel(), BorderLayout.SOUTH);

        this.setTitle("Group anotation change: ");

        this.setVisible(true);
        this.setBounds(400, 100, 400, 400);

    }

    private JPanel createButtonsPanel() {

        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton confirmButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        confirmButton.addActionListener(new SaveListener());
        cancelButton.addActionListener(new CancelListener());

        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);

        return buttonPanel;

    }

    private JPanel createAnnotItemPanel(String annotName, String value, boolean param) {

        Object [] itemsGui = new Object[3];

        JPanel itemPanel = new JPanel(new GridLayout(1, 3, 30, 5));

        JLabel aLabel = new JLabel(annotName);
        JCheckBox aBox = new JCheckBox();
        aBox.addActionListener(new CheckListener());
        JTextField aField = new JTextField();
        aField.setEditable(false);

        if (!param) {
            aField.setVisible(false);
        }

        if (value != null) {
            aBox.setSelected(true);
            aField.setText(value);
            aField.setEditable(true);
        }

        JPanel leftPanel = new JPanel(new BorderLayout(5, 1));
        leftPanel.add(aLabel, BorderLayout.CENTER);
        leftPanel.add(aBox, BorderLayout.EAST);

        itemPanel.add(leftPanel);
        itemPanel.add(aField);

        itemsGui[0] = aLabel;
        itemsGui[1] = aBox;
        itemsGui[2] = aField;

        guiItems.add(itemsGui);
        return itemPanel;
    }

    private JPanel createHeader() {

        JPanel itemPanel = new JPanel(new GridLayout(1, 3, 30, 5));

        JLabel aLabel = new JLabel("Annotation");
        JLabel aBox = new JLabel("Add");
        
        JLabel aField = new JLabel("Value");
        
        JPanel leftPanel = new JPanel(new BorderLayout(5, 1));
        leftPanel.add(aLabel, BorderLayout.CENTER);
        leftPanel.add(aBox, BorderLayout.EAST);

        itemPanel.add(leftPanel);
        itemPanel.add(aField);

        leftPanel.setBackground(Color.LIGHT_GRAY);
        itemPanel.setBackground(Color.LIGHT_GRAY);
        itemPanel.setBorder(BorderFactory.createEtchedBorder());

        return itemPanel;
    }

    private JScrollPane createAnnotPanel(List<Iannotation> items) {

        JPanel aPanel = new JPanel(new GridLayout(items.size()+1, 1, 5, 5));

        aPanel.add(createHeader());

        for (Iannotation annotation: items) {

            if (annotation.isChangen()) {

                aPanel.add(createAnnotItemPanel(annotation.getName(), annotation.getValue(), annotation.isParam()));
            }else {
                aPanel.add(createAnnotItemPanel(annotation.getName(), null, annotation.isParam()));
            }
        }

        JPanel posPanel = new JPanel(new BorderLayout());
        posPanel.setBorder(BorderFactory.createMatteBorder(10, 10, 10, 10, posPanel.getBackground()));
        posPanel.add(aPanel, BorderLayout.NORTH);


        JScrollPane scrollPanel = new JScrollPane(posPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        return scrollPanel;
    }


    private class SaveListener implements ActionListener{

        public void actionPerformed(ActionEvent e) {

            if (groupChange) {

                for (String[] item: selectedAttrs){
                    classAnnotName = item[0];
                    if (item[1] != null){
                        
                        attrAnnotName = item[1];
                    }else{
                        attrAnnotName = null;
                    }
                    applyChanges();
                }

            }else {
                applyChanges();
            }
            
            frame.dispose();
        }

        private void applyChanges() {

            for (Object[]  object: guiItems) {

                String name = ((JLabel) object[0]).getText();
                boolean changed = ((JCheckBox)object[1]).isSelected();
                String value = ((JTextField) object[2]).getText();

                String recent = value;

                if (!changed) { // erase value if checkBox not checked
                    value = null;
                }

                if (attrAnnotName != null) { // attribut annotations

                    if (project.isAttrAnnotParam(classAnnotName, attrAnnotName, name)) {//parametric

                        if (!recent.equals(""))
                        project.changeAttributeAnnotation(classAnnotName, attrAnnotName, name, value);
                    }else {
                        project.changeNoParAttributeAnnotation(classAnnotName,attrAnnotName, name, changed);
                    }
                }else { // class annotations

                    if (project.isClassAnnotParam(classAnnotName, name)) { //parametric

                        if (!recent.equals(""))
                        project.changeClassAnnotation(classAnnotName, name, value);
                    }else {
                        project.changeNoParClassAnnotation(classAnnotName, name, changed);
                    }
                }
            }
         ListenerDiffs.updateThumbnail();
        }
    }

    private class CancelListener implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            frame.dispose();
        }

    }

    private class CheckListener implements ActionListener{

        public void actionPerformed(ActionEvent e) {

            JCheckBox source = (JCheckBox) e.getSource();

            for (Object[] item: guiItems) {

                JCheckBox box = (JCheckBox) item[1];

                if (box.hashCode() == source.hashCode()) {

                    if (source.isSelected()) {
                       ((JTextField) item[2]).setEditable(true);
                    }else {
                        ((JTextField) item[2]).setEditable(false);
                    }
                    break;
                }
            }
        }
    }
}
