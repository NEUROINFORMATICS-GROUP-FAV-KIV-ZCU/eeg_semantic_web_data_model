package cz.zcu.kiv.annotations.gui;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Filip Markvart
 */
public class ItemSelectTableModel extends AbstractTableModel{

    Map<File, String> classes;


    public ItemSelectTableModel(){

        classes = new TreeMap<File, String>();
    }


    public int getRowCount() {

        return classes.size();
    }

    public int getColumnCount() {

        return 1;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {

        int i = 0;

        for (Map.Entry<File, String> item: classes.entrySet()){

            if (i == rowIndex){

                return item.getKey().getName();
            }
            i++;
        }
        return null;
    }

    public void addItems(File[] files, String pckgName) {

        if (files == null) return;

        for (File item: files){
            classes.put(item, pckgName);
        }
        super.fireTableDataChanged();
    }

    public void removeItem(List<String> selected) {

        for (String itemString : selected) {

            for (Map.Entry<File, String> item : classes.entrySet()) {

                if (item.getKey().getName().equals(itemString)) {
                    classes.remove(item.getKey());
                    break;
                }
            }
            super.fireTableDataChanged();
        }
    }

    public Map<File, String> getData() {
        return classes;
    }

    @Override
    public String getColumnName(int column) {

        return "Selected classes:";
    }
}
