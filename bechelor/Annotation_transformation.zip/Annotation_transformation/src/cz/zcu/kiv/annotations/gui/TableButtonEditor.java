package cz.zcu.kiv.annotations.gui;

import java.awt.Component;
import java.util.EventObject;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.event.CellEditorListener;
import javax.swing.table.TableCellEditor;

/**
 * Change button of main frame's JTable that visualises this button
 *
 * @author Filip Markvart
 */
public class TableButtonEditor implements TableCellEditor{

    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        return (JButton)value;
    }

    public Object getCellEditorValue() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean isCellEditable(EventObject anEvent) {
        return true;
    }

    public boolean shouldSelectCell(EventObject anEvent) {
        return true;
    }

    public boolean stopCellEditing() {
        return true;
    }

    public void cancelCellEditing() {
        
    }

    public void addCellEditorListener(CellEditorListener l) {
        
    }

    public void removeCellEditorListener(CellEditorListener l) {
        
    }


}
