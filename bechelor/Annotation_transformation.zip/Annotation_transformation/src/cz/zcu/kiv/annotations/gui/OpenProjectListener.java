package cz.zcu.kiv.annotations.gui;

import cz.zcu.kiv.annotations.application.IprojectManager;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.JTabbedPane;
import javax.swing.filechooser.FileFilter;
import cz.zcu.kiv.annotations.application.ProjectManager;
import javax.swing.JOptionPane;

/**
 * Menu item open project listener calls methods to open user selected annotation
 * project save on disk and reads all included data - classes and their user
 * added annotations
 *
 * @author Filip Markvart
 */
class OpenProjectListener implements ActionListener{


    private Frame mainWindow;
    
    private IprojectManager project;

    private DisplayProjectData displayAttrData;
    private DisplayProjectData displayClassData;

     public OpenProjectListener(IprojectManager project, Frame mainWindow, JTabbedPane attrPane, JTabbedPane classPane) {

        this.mainWindow = mainWindow;
        
        this.project = project;

        this.displayAttrData = new DisplayProjectData(project, attrPane, false, mainWindow);
        this.displayClassData = new DisplayProjectData(project, classPane, true, mainWindow);
     }

    public void actionPerformed(ActionEvent e) {

        File selected = getSelectedFile();

        if (selected != null) {

            if (project.openExistingProject(selected) == 0) {

                displayAttrData.displayLists();
                displayClassData.displayLists();
                mainWindow.setTitle("Annotation utility: " + selected.getName());

                AppStatus.subItemGenerateJaif.setEnabled(true);
                AppStatus.subItemSaveAsProject.setEnabled(true);
                AppStatus.subItemSaveProject.setEnabled(true);
                
                AppStatus.savedFileName = selected;

            } else{

                displayAttrData.clear();
                displayClassData.clear();
                AppStatus.subItemGenerateJaif.setEnabled(false);
                AppStatus.subItemSaveAsProject.setEnabled(false);
                AppStatus.subItemSaveProject.setEnabled(false);

                JOptionPane.showMessageDialog(mainWindow, "Can not open project.");
            }
        }
    }

    /**
     * Method opens a dialog to enable to user
     * choose annotation project to open.
     *
     * @return Selected file
     */
    private File getSelectedFile() {

        JFileChooser fileChooser = new JFileChooser(AppStatus.openPath);

        fileChooser.setMultiSelectionEnabled(false);
        fileChooser.setAcceptAllFileFilterUsed(true);
        fileChooser.setFileFilter(new SelectedFilter("apf"));

        if ((fileChooser.showDialog(mainWindow, "Select file") == 0)) {

            AppStatus.openPath = fileChooser.getSelectedFile().getPath();
            return fileChooser.getSelectedFile();

        } else {
            return null;
        }
    }

    /**
     * File filter defines the selected file format
     * of Annotation project file
     */
    public class SelectedFilter extends FileFilter {

        String suffix;

        private SelectedFilter(String type) {

            suffix = type;
        }

	@Override
	public boolean accept(File f) {

            if (f.isDirectory()) return true;
            if (f.getName().contains(suffix) || f.getName().contains(suffix.toUpperCase())) {

                return true;
            }else {
                return false;
            }
        }

	@Override
	public String getDescription() {

            return suffix;
	}
    }


}
