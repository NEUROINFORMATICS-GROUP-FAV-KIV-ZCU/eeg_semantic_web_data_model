package cz.zcu.kiv.annotations.gui;

import java.io.File;
import javax.swing.JMenuItem;

/**
 * This class contains actual state of the tool program.
 *
 * @author Filip Markvart
 */
public class AppStatus {

    public static JMenuItem subItemOpenProject;
    public static JMenuItem subItemSaveAsProject;
    public static JMenuItem subItemSaveProject;
    public static JMenuItem subItemNewProject;
    public static JMenuItem subItemGenerateJaif;

    public static String openPath = ".";
    public static String savePath = ".";
    public static String loadClassesPath = ".";

    public static File savedFileName;

    public static boolean readyProject;


    public static boolean checkURI;
}
