package cz.zcu.kiv.annotations.data;

/**
 * Data class containing one annotation fixed to attribute
 *
 * @author Filip Markvart
 */
public class FileSavedAnnotAttr extends FileSavedAnnotation {

    private String AttrName;

    public FileSavedAnnotAttr(String packageName, String className, String annotName, String annotVal, String attrName) {

        super(packageName, className, annotName, annotVal);
        this.AttrName = attrName;
    }

    public String getAttrName() {

        return AttrName;
    }
}
