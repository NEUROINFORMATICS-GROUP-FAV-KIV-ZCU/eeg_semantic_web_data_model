package cz.zcu.kiv.annotations.gui;

/**
 * Main class creates a gui window.
 *
 * @author Filip Markvart
 */
public class Run {

    public static void main(String args[]) {

        MainWindow anootationsa = new MainWindow();
    }
}
