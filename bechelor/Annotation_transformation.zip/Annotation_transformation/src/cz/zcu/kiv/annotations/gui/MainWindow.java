package cz.zcu.kiv.annotations.gui;

import cz.zcu.kiv.annotations.application.IprojectManager;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import cz.zcu.kiv.annotations.application.ProjectManager;
import java.awt.Color;
import java.awt.Frame;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;

/**
 * This class is represents a main part of the gui.
 * It creates a gui window where are all annotation items
 * of all loaded classes.
 * The main menu enables to create, open and save project with
 * user defined annotations.
 *
 * @author Filip Markvart
 */
public class MainWindow extends JFrame{

private static IprojectManager project;

private static JTabbedPane attrPane; // bookmarks attributes
private static JTabbedPane classPane; // bookmarks attributes

     /**
     * Constructor creates the basic gui items and main menu.
     *
     */
    public MainWindow(){

        project = new ProjectManager();
        attrPane = new JTabbedPane(); //all lists with annotations attrs
        classPane = new JTabbedPane(); //all lists with annotations classes

        JPanel mainPanel = new JPanel(); // center panel
        mainPanel.setLayout(new BorderLayout());

        JPanel secondPanel = new JPanel(); // center panel
        secondPanel.setLayout(new BorderLayout());

        mainPanel.add(attrPane, BorderLayout.CENTER); // all annotaion lists attr
        secondPanel.add(classPane, BorderLayout.CENTER); // all annotaion lists classes

        classPane.setBorder(BorderFactory.createEmptyBorder());
        attrPane.setBorder(BorderFactory.createEmptyBorder());
        mainPanel.setBorder(BorderFactory.createEmptyBorder());
        secondPanel.setBorder(BorderFactory.createEmptyBorder());

        JTabbedPane sidePane = new JTabbedPane(JTabbedPane.RIGHT); //left side with all listst included
        sidePane.setBackground(Color.WHITE);

        sidePane.addTab("Attributes", mainPanel);
        sidePane.addTab("Classes", secondPanel);

        sidePane.setBorder(BorderFactory.createEmptyBorder());

        this.add(sidePane); // the main part
        this.setJMenuBar(createMenu()); // creates a menu

        

	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setTitle("Anotation tool");
	this.setBounds(300, 100, 900, 600);
	this.setVisible(true);
	}

    /**
     * Method creates the main menu bar with each subitem and
     * sets all listeners to all items.
     *
     * @return created JMenuBar
     */
    public JMenuBar createMenu() {

        JMenuBar menu = new JMenuBar(); 

	JMenu menuItemProject = new JMenu("Project");

	menu.add(menuItemProject);

	AppStatus.subItemOpenProject = new JMenuItem("Open project");
	AppStatus.subItemSaveAsProject = new JMenuItem("Save as");
        AppStatus.subItemSaveProject = new JMenuItem("Save");
	AppStatus.subItemNewProject = new JMenuItem("New project");

	menuItemProject.add(AppStatus.subItemNewProject);
	menuItemProject.add(AppStatus.subItemOpenProject);
	menuItemProject.add(AppStatus.subItemSaveAsProject);
        menuItemProject.add(AppStatus.subItemSaveProject);

        JMenu menuItem = new JMenu("Annotation");

        menu.add(menuItem);

	AppStatus.subItemGenerateJaif = new JMenuItem("Export classes");
        
        AppStatus.subItemGenerateJaif.setEnabled(false);
        AppStatus.subItemSaveAsProject.setEnabled(false);
        AppStatus.subItemSaveProject.setEnabled(false);


        menuItem.add(AppStatus.subItemGenerateJaif);

	AppStatus.subItemGenerateJaif.addActionListener(new ExportClassesListener(project, this));
	AppStatus.subItemNewProject.addActionListener(new NewProjectListener(project, this, attrPane, classPane));
	AppStatus.subItemOpenProject.addActionListener(new OpenProjectListener(project, this, attrPane, classPane));
	AppStatus.subItemSaveAsProject.addActionListener(new SaveAsProjectListener(project, this));

        AppStatus.subItemSaveProject.addActionListener(new SaveProjectList());

	return menu;
    }


    private static class SaveProjectList implements ActionListener{

        public void actionPerformed(ActionEvent e) {

             if (project.saveProject(AppStatus.savedFileName)) {

            }else {
                JOptionPane.showMessageDialog(new Frame(), "Can not save project.");
            }
        }


    }
}