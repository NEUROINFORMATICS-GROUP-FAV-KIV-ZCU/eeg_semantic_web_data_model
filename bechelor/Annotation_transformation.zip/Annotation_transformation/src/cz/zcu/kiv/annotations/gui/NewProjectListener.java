package cz.zcu.kiv.annotations.gui;

import cz.zcu.kiv.annotations.application.IprojectManager;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.filechooser.FileFilter;
import cz.zcu.kiv.annotations.application.ProjectManager;

/**
 * Listener of menuItem New Project contains methods
 * to create a new project by selecting user chosed
 * classes asi single classes or packeg in jar file.
 *
 * A target project file is saved to selected path.
 * A new project is automaticly opened.
 *
 * @author Filip Markvart
 */
public class NewProjectListener implements ActionListener{

    private Frame mainWindow;
    private IprojectManager project;

    private DisplayProjectData dispalyAttrData;
    private DisplayProjectData dispalyClassData;
    /**
     * Constructor gets all neccessary atributes to access
     * to all needed components.
     *
     * @param mainWindow Gui main window.
     */
    public NewProjectListener(IprojectManager project, Frame mainWindow, JTabbedPane attrPane, JTabbedPane classPane) {

        this.mainWindow = mainWindow;
        this.project = project;

        this.dispalyAttrData = new DisplayProjectData(project, attrPane, false, mainWindow);
        this.dispalyClassData = new DisplayProjectData(project, classPane, true, mainWindow);
    }

    /**
     * Selecting the menu item invokes opening the dialog
     * to specify a project details.
     *
     * @param e
     */
    public void actionPerformed(ActionEvent e) {

        int selectedFormat = selectedFileType(); // including single classes or JAR
        int pPrepare = -1; // if project is prepared

        List<File> selected;


        String packageName = ""; // name of the class containing package

        if (selectedFormat == 0) { // JAR type classes

            selected = getSelectedFiles(true);

            if (selected != null) { // one JAR was selected

                packageName = getPackageName();

                if (packageName != null) {

                    pPrepare = project.createProject(selected.get(0), packageName, false); 
                }else {
                    return;
                }
            }else return;
        }else if (selectedFormat == 1 ) { // single classes
           // a new window with file chooser table

            new ItemChooser(false, project, dispalyAttrData, dispalyClassData);

            return;


        }else if (selectedFormat == 2) { // JAR type sources

            selected = getSelectedFiles(true);

            if (selected != null) { // one JAR was selected

                pPrepare = project.createProject(selected.get(0), null, true); 
                
            }else return;
        }else if (selectedFormat == 3 ) { //new window select single sources

            new ItemChooser(true, project, dispalyAttrData, dispalyClassData);
            return;
        }
        else {
            return;
        }

        if (pPrepare == 0) {
            // view data, ok
            dispalyAttrData.displayLists();
            dispalyClassData.displayLists();
            AppStatus.subItemGenerateJaif.setEnabled(true);
            AppStatus.subItemSaveAsProject.setEnabled(true);
            

        }else { // else show error
            dispalyAttrData.clear();
            dispalyClassData.clear();
            AppStatus.subItemGenerateJaif.setEnabled(false);
            AppStatus.subItemSaveAsProject.setEnabled(false);
            AppStatus.subItemSaveProject.setEnabled(false);

            if (pPrepare == 1) {//can not find ini file
                JOptionPane.showMessageDialog(mainWindow, "Can not find .ini files of Annotation tool");
            }else if (pPrepare == 2){ // can not load classes
                JOptionPane.showMessageDialog(mainWindow, "Can not load classes");
            }else {
                JOptionPane.showMessageDialog(mainWindow, "Class reference to unavailable class or bad package name");
            }
        }
    }
    /**
     * Method shows a dialog asking user to select file type
     * in which import the classes he wants to annotate.
     *
     * @return int value of selected type. 0 - JAR type
     *                                     1 - single classes
     *                                     2 - JAR source
     *                                     3 - single sources
     *                                     other - canceled
     */
    private int selectedFileType() {

        Object[] options = {"JAR", "single Classes", "JAR source", "single sources", "cancel"};
        String question = "Do you want import files from JAR or single classes?";

        int fileType = JOptionPane.showOptionDialog(mainWindow, question,
                                   "Format select",
                                   JOptionPane.YES_NO_CANCEL_OPTION,
                                   JOptionPane.QUESTION_MESSAGE,
                                   null, options, options[4]);
        return fileType;
    }


    /**
     * Method opens a dialog to enable to user
     * choose all class files.
     *
     * @param typeJAR Boolean if classe is zipped in JAR file.
     *
     * @return Selected files
     */
    private List<File> getSelectedFiles(boolean typeJAR) {

        List<File> selected = new ArrayList<File>();

        JFileChooser fileChooser = new JFileChooser(AppStatus.loadClassesPath);

        if (typeJAR) { // JAR

            fileChooser.setMultiSelectionEnabled(false);
            fileChooser.setAcceptAllFileFilterUsed(true);
            fileChooser.setFileFilter(new SelectedFilter("jar"));

            if ((fileChooser.showDialog(mainWindow, "Select file") == 0)) {

                selected.add(fileChooser.getSelectedFile());

                AppStatus.loadClassesPath = fileChooser.getSelectedFile().getPath();
                return selected;

            }else {
              return null;
            }


        }else  { //single classes

            fileChooser.setMultiSelectionEnabled(true);
            fileChooser.setAcceptAllFileFilterUsed(true);
            fileChooser.setFileFilter(new SelectedFilter("class"));

            if ((fileChooser.showDialog(mainWindow, "Select file") == 0)) {

               File [] selectedFiles = fileChooser.getSelectedFiles();
                
                for (int i = 0; i < selectedFiles.length; i ++) {

                    selected.add(selectedFiles[i]);
                }
                AppStatus.loadClassesPath = fileChooser.getSelectedFile().getPath();
                return selected;
            }else {
              return null;
            }
        }
    }

    /**
     * Method shows a input dialog to enter the name of package
     * containing selected package
     *
     * @return the package name or null if canceled by user
     */

    public String getPackageName() {

        Object[] textNote = {"Enter the name of classes package:"};

	String packName= (String)JOptionPane.showInputDialog(textNote);

        return packName;
    }

    /**
     * File filter defines the selected file format
     * of structure to importing files from
     */
    public class SelectedFilter extends FileFilter {

        String suffix;

        private SelectedFilter(String type) {

            suffix = type;
        }

	@Override
	public boolean accept(File f) {

            if (f.isDirectory()) return true;
            if (f.getName().endsWith(suffix) || f.getName().endsWith(suffix.toUpperCase())) {

                return true;
            }else {
                return false;
            }
        }

	@Override
	public String getDescription() {

            return suffix;
	}
    }
}
