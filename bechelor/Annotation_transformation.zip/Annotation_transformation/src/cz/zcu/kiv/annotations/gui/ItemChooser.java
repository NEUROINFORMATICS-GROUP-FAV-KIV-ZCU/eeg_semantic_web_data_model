package cz.zcu.kiv.annotations.gui;

import cz.zcu.kiv.annotations.application.IprojectManager;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;

/**
 *
 * @author Filip Markvart
 */
public class ItemChooser extends JFrame{

    private ItemSelectTableModel model;
    private JFrame thisFrame;
    private boolean isSource;
    private JTable itemsTable;

    private IprojectManager project;
    private DisplayProjectData attrData;
    private DisplayProjectData classData;


    public ItemChooser(boolean sourceSelect, IprojectManager project, DisplayProjectData attrData, DisplayProjectData classData){

        this.thisFrame = this;
        this.isSource = sourceSelect;
        this.project = project;
        this.attrData = attrData;
        this.classData = classData;

        this.model = new ItemSelectTableModel();
        this.itemsTable = new JTable(model);

        this.add(createMainPanel());
        
	this.setTitle("Items select");
	this.setBounds(400, 100, 600, 500);
	this.setVisible(true);
    }

    private JPanel createMainPanel() {

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.yellow);

        
        mainPanel.add(new JScrollPane(itemsTable, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED), BorderLayout.CENTER);
        mainPanel.add(createRigthMenu(), BorderLayout.EAST);

        return mainPanel;
    }


    private JPanel createRigthMenu() {

        JPanel topPanel = new JPanel(new GridLayout(4,1));
        topPanel.add(new JPanel());

        JButton addButton = new JButton(" " + " " +" " + " " + " " + " Add more " + " " + " " + " " + " "+ " " + " ");
        addButton.addActionListener(new AddListener());
        JButton removeButton = new JButton("Remove selected");
        removeButton.addActionListener(new RemoveListener());

        JPanel subPanel0 = new JPanel(new FlowLayout());
        subPanel0.add(addButton);
        topPanel.add(subPanel0);


        JPanel subPanel1 = new JPanel(new FlowLayout());

        subPanel1.add(removeButton);
        topPanel.add(subPanel1);

        topPanel.add(new JPanel());

        // MIDDLE -------------------
        JPanel middleEmptyPanel = new JPanel();
        // BOTTOM ---------------------

        JPanel bottomPanel = new JPanel(new GridLayout(4,1));
        bottomPanel.add(new JPanel());


        JButton okButton = new JButton(" " + " " + " " + "OK " + " " + " " + " " );
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new CancelListener());
        okButton.addActionListener(new OkListener());

        JPanel subPanel2 = new JPanel(new FlowLayout());
        bottomPanel.add(subPanel2);

        
        JPanel subPanel3 = new JPanel(new FlowLayout());
        subPanel3.add(okButton);
        subPanel3.add(cancelButton);
        bottomPanel.add(subPanel3);

        bottomPanel.add(new JPanel());

        JPanel menuPanel = new JPanel(new GridLayout(3,1));

        menuPanel.add(topPanel);
        menuPanel.add(middleEmptyPanel);
        menuPanel.add(bottomPanel);

        menuPanel.setBorder(BorderFactory.createEtchedBorder());

        return menuPanel;
    }


    private class CancelListener implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            thisFrame.dispose();
        }

    }

    private class OkListener implements ActionListener{

        public void actionPerformed(ActionEvent e) {

            int pPrepare = -1;

            if (model.getData().isEmpty()) {
                thisFrame.dispose();
                return;
            }

            pPrepare = project.createProject(model.getData(), isSource);

        if (pPrepare == 0) {
            // view data, ok
            attrData.displayLists();
            classData.displayLists();
            AppStatus.subItemGenerateJaif.setEnabled(true);
            AppStatus.subItemSaveAsProject.setEnabled(true);


        }else { // else show error
            attrData.clear();
            classData.clear();
            AppStatus.subItemGenerateJaif.setEnabled(false);
            AppStatus.subItemSaveAsProject.setEnabled(false);
            AppStatus.subItemSaveProject.setEnabled(false);

            if (pPrepare == 1) {//can not find ini file
                JOptionPane.showMessageDialog(thisFrame, "Can not find .ini files of Annotation tool");
            }else if (pPrepare == 2){ // can not load classes
                JOptionPane.showMessageDialog(thisFrame, "Can not load classes");
            }else {
                JOptionPane.showMessageDialog(thisFrame, "Class reference to unavailable class or bad package name");
            }
        }
            thisFrame.dispose();

        }
    }

    private class RemoveListener implements ActionListener{

        public void actionPerformed(ActionEvent e) {

            int selected[] = itemsTable.getSelectedRows();

            if (selected == null) return;

            List<String> selectedItems = new ArrayList<String>() ;

            for (int actual: selected) {

                selectedItems.add((String) model.getValueAt(actual, 0));
            }
            model.removeItem(selectedItems);
        }

    }

    private class AddListener implements ActionListener{

        public void actionPerformed(ActionEvent e) {

            File[] selected = getSelectedFiles();
            String pckgName = null;

            if (!isSource) pckgName = getPackageName();

            if (pckgName == null && !isSource) return;
            
            model.addItems(selected, pckgName);
        }


        /**
     * Method opens a dialog to enable to user
     * choose all class files.
     *
     * @param typeJAR Boolean if classe is zipped in JAR file.
     *
     * @return Selected files
     */
    private File[] getSelectedFiles() {

        JFileChooser fileChooser = new JFileChooser(AppStatus.loadClassesPath);

        fileChooser.setMultiSelectionEnabled(true);
        fileChooser.setAcceptAllFileFilterUsed(true);

        if (isSource) {
            fileChooser.setFileFilter(new SelectedFilter("java"));
        }else {
            fileChooser.setFileFilter(new SelectedFilter("class"));
        }

            if ((fileChooser.showDialog(thisFrame, "Select file") == 0)) {

                AppStatus.loadClassesPath = fileChooser.getSelectedFile().getPath();

                return fileChooser.getSelectedFiles();

            }else {
              return null;
            }

    }

    /**
     * Method shows a input dialog to enter the name of package
     * containing selected package
     *
     * @return the package name or null if canceled by user
     */

    public String getPackageName() {

        Object[] textNote = {"Enter the name of classes package:"};

	String packName= (String)JOptionPane.showInputDialog(textNote);

        return packName;
    }

    }

    /**
     * File filter defines the selected file format
     * of structure to importing files from
     */
    private class SelectedFilter extends FileFilter {

        String suffix;

        private SelectedFilter(String type) {

            suffix = type;
        }

	@Override
	public boolean accept(File f) {

            if (f.isDirectory()) return true;
            if (f.getName().endsWith(suffix) || f.getName().endsWith(suffix.toUpperCase())) {

                return true;
            }else {
                return false;
            }
        }

        @Override
	public String getDescription() {

            return suffix;
	}
    }
}
