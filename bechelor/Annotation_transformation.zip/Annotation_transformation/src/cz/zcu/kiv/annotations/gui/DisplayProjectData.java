package cz.zcu.kiv.annotations.gui;

import cz.zcu.kiv.annotations.application.CommonAnnots;
import cz.zcu.kiv.annotations.application.IprojectManager;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import cz.zcu.kiv.annotations.application.ProjectManager;
import cz.zcu.kiv.annotations.data.Iattribute;
import cz.zcu.kiv.annotations.data.IclassItem;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;

/**
 * This class gather classes names and atributes from project
 * and shows these data in main window as list which contains
 * each classes with atributes
 *
 * @author Filip Markvart
 */
public class DisplayProjectData {

    private JTabbedPane tabePane; //list attrs
    private IprojectManager project;
    private boolean classPane;
    
    private Map<String, Map<JLabel, JButton>> guiMap;
   
   
    private Frame root;

    public DisplayProjectData(IprojectManager project, JTabbedPane tabePane, boolean classPane, Frame root) {

        this.tabePane = tabePane;
        this.project = project;
        this.classPane = classPane;
        guiMap = new HashMap<String, Map<JLabel, JButton>>();

        this.root = root;
    }

    /**
     * Method add all gui lists which contains all atributes of classes
     * to main window.
     *
     */
    public void displayLists() {

        tabePane.removeAll();
        guiMap.clear();

        JPanel itemList;

        if (classPane) { //only classes

            itemList = addListClasses(project.getClasses());
            itemList.setBorder(BorderFactory.createEmptyBorder());

            JScrollPane layoutPanel = new JScrollPane(itemList);
            layoutPanel.setBorder(BorderFactory.createEmptyBorder());

            tabePane.addTab("All classes", layoutPanel);

        } else { //class and attributes

            for (IclassItem classItem : project.getClasses()) {

                itemList = addList(classItem);
                itemList.setBorder(BorderFactory.createEmptyBorder());

                JScrollPane layoutPanel = new JScrollPane(itemList);
                layoutPanel.setBorder(BorderFactory.createEmptyBorder());

                tabePane.addTab(classItem.getName(), layoutPanel);
            }
        }
    }

    /**
     * Method clears all lists.
     */
    public void clear() {
        tabePane.removeAll();
        guiMap.clear();
    }

    /**
     * Method creates a panel containg all classes atributes
     * in selected class a shows these atributes as gui items
     * by specified layout.
     *
     * @param items String list of atributes
     * @param className Name of the class
     * @return JPanel containig all gui parts
     */
    private JPanel addList(IclassItem itemClass) {

        List<String[]> selectedAttrs = new ArrayList<String[]>(); // attributes selected in JTable
        
        JPanel thumbPanelInner = new JPanel();

        JLabel itemLabel;
        JButton itemButton;

        Map<JLabel, JButton> classItemList = new HashMap<JLabel, JButton>();
        
        List<JLabel> labels = new ArrayList<JLabel>();
        List<JButton> buttons = new ArrayList<JButton>();

        JTable listTable = new JTable();

        TableActionListener tMouseListener = new TableActionListener(listTable, selectedAttrs, labels, itemClass.getName(), thumbPanelInner, false);

        itemLabel = new JLabel("Class");
        
        labels.add(itemLabel);

        itemButton = new JButton("Change");
        itemButton.addActionListener(new ButtonChangeListener(project, guiMap, tMouseListener));
        buttons.add(itemButton);

        classItemList.put(new JLabel("ParentClass"), itemButton);

        for (Iattribute itemAttr : itemClass.getClassAttributes()) { // cycle trough all attributes of class

            itemLabel = new JLabel(itemAttr.getName());
            labels.add(itemLabel);
            
            itemButton = new JButton("Change");
            itemButton.addActionListener(new ButtonChangeListener(project, guiMap, tMouseListener));
            buttons.add(itemButton);

            classItemList.put(itemLabel, itemButton);
        }
        guiMap.put(itemClass.getName(), classItemList);

        JPanel vPanel = new JPanel();
        vPanel.setLayout(new BorderLayout());
        
        listTable.setModel(new JTableDataModel(labels, buttons));
        listTable.setBorder(BorderFactory.createEtchedBorder());
        listTable.setDefaultRenderer(JButton.class, new TableButtonRenderer());
        listTable.setDefaultRenderer(JLabel.class, new TableLabelRenderer());
        listTable.setCellEditor(new TableButtonEditor());
        listTable.addMouseListener(new JTableMouseButtonListener(listTable));
        listTable.setRowHeight(20);
        
        listTable.addMouseListener(tMouseListener);
        listTable.addKeyListener(new TableActionListener(listTable, selectedAttrs, labels, itemClass.getName(), thumbPanelInner, false));


        vPanel.add(listTable, BorderLayout.NORTH);
        vPanel.setBorder(BorderFactory.createMatteBorder(5, 5, 5, 150, vPanel.getBackground()));

        JPanel rootPane = new JPanel(new GridLayout(1, 2)); // main panel

        JPanel thumbPanel = new JPanel(new GridLayout(1, 1));
        thumbPanel.setBackground(Color.red);
        thumbPanel.setBorder(BorderFactory.createMatteBorder(50, 10, 100, 20, rootPane.getBackground()));

        thumbPanel.add(createThumb(selectedAttrs, tMouseListener, thumbPanelInner)); // Thumbnail frame
        rootPane.add(vPanel); 
        rootPane.add(thumbPanel);

        return rootPane;
    }

    /**
     * Method creates a panel containg all classes annotations
     * and shows these annoataions as gui items
     * by specified layout.
     *
     * @param items String list of atributes
     * @param className Name of the class
     * @return JPanel containig all gui parts
     */
    private JPanel addListClasses(List<IclassItem> itemClass) {

        List<String[]> selectedClasses = new ArrayList<String[]>(); // classes selected in JTable

        JPanel thumbPanelInner = new JPanel();

        JLabel itemLabel;
        JButton itemButton;

        Map<JLabel, JButton> classItemList = new HashMap<JLabel, JButton>();

        List<JLabel> labels = new ArrayList<JLabel>();
        List<JButton> buttons = new ArrayList<JButton>();

        JTable listTable = new JTable();

        TableActionListener tMouseListener = new TableActionListener(listTable, selectedClasses, labels, "", thumbPanelInner, true);

        for (IclassItem item : itemClass) { // cycle trough all classes

            itemLabel = new JLabel(item.getName());
            labels.add(itemLabel);

            itemButton = new JButton("Change");
            itemButton.addActionListener(new ButtonChangeListener(project, guiMap, tMouseListener));
            buttons.add(itemButton);

            classItemList.put(itemLabel, itemButton);

            guiMap.put(item.getName(), classItemList);
        }

        JPanel vPanel = new JPanel();
        vPanel.setLayout(new BorderLayout());

        listTable.setModel(new JTableDataModel(labels, buttons));
        listTable.setBorder(BorderFactory.createEtchedBorder());
        listTable.setDefaultRenderer(JButton.class, new TableButtonRenderer());
        listTable.setDefaultRenderer(JLabel.class, new TableLabelRenderer());
        listTable.setCellEditor(new TableButtonEditor());
        listTable.addMouseListener(new JTableMouseButtonListener(listTable));
        listTable.setRowHeight(20);

        listTable.addMouseListener(tMouseListener);
        listTable.addKeyListener(new TableActionListener(listTable, selectedClasses, labels, "", thumbPanelInner, true));


        vPanel.add(listTable, BorderLayout.NORTH);
        vPanel.setBorder(BorderFactory.createMatteBorder(5, 5, 5, 150, vPanel.getBackground()));

        JPanel rootPane = new JPanel(new GridLayout(1, 2)); // main panel

        JPanel thumbPanel = new JPanel(new GridLayout(1, 1));
        thumbPanel.setBackground(Color.red);
        thumbPanel.setBorder(BorderFactory.createMatteBorder(50, 10, 100, 20, rootPane.getBackground()));

        thumbPanel.add(createThumb(selectedClasses, tMouseListener, thumbPanelInner)); // Thumbnail frame
        rootPane.add(vPanel);
        rootPane.add(thumbPanel);

        return rootPane;
    }

    private JPanel createThumb(List<String[]> selected, TableActionListener ListenerDiffs, JPanel innerData) {

        JPanel thumbPanelAttr = new JPanel(new BorderLayout());

        JButton groupChButton = new JButton("Change selected");

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(groupChButton);

        groupChButton.addActionListener(new ButtonChGroupListener(project, selected, ListenerDiffs));

        
        innerData.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Common annotations", TitledBorder.CENTER, TitledBorder.TOP));

        thumbPanelAttr.add(innerData, BorderLayout.CENTER);
        thumbPanelAttr.add(buttonPanel, BorderLayout.SOUTH);

        return thumbPanelAttr;

    }

   
    public class TableActionListener implements MouseListener, KeyListener {

        private List<String[]> selectedAttrs;
        private JTable sourceTable;
        private List<JLabel> labels;
        private String className;
        private JPanel thumbPanel;
        private boolean classList;


        public TableActionListener(JTable sourceTable, List<String[]> selectedAttrs, List<JLabel> labels, String className, JPanel thumbPanel, boolean classList) {

            this.selectedAttrs = selectedAttrs;
            this.sourceTable = sourceTable;
            this.labels = labels;
            this.className = className;
            this.thumbPanel = thumbPanel;
            this.classList = classList;
        }

        public void mouseClicked(MouseEvent e) { action(); }

        public void mousePressed(MouseEvent e) { action(); }

        public void mouseReleased(MouseEvent e) { action(); }

        public void mouseEntered(MouseEvent e)  { action(); }

        public void mouseExited(MouseEvent e) { action(); }

        public void keyTyped(KeyEvent e) { action(); }

        public void keyPressed(KeyEvent e) { action(); }

        public void keyReleased(KeyEvent e) { action(); }

        private void action(){

            boolean rootSelected = false;
            int rootIndex = -1;

            int[] selectedRows = sourceTable.getSelectedRows();

            selectedAttrs.clear();


            for (int i: selectedRows){

                String[] selected = new String[2];
                
                if (classList) {
                    selected[0] = labels.get(i).getText();
                    selected[1] = null;
                }else{
                    selected[0] = className;
                    selected[1] = labels.get(i).getText();
                }

                if (labels.get(i).getText().equals("Class")) { 
                    rootIndex = i;
                    rootSelected = true;
                    selected[1] = null;
                }

                selectedAttrs.add(selected);
            }

            if ((selectedAttrs.size() > 1) && rootSelected) selectedAttrs.remove(rootIndex);
             
            updateThumbnail();       
        }
          public void updateThumbnail() {

                thumbPanel.removeAll();

                thumbPanel.add(getCommonData(selectedAttrs));
                
                root.repaint();
            }

        private JPanel getCommonData(List<String[]> selected) {

            if (selected.isEmpty()) return new JPanel();

            List<String[]> commData = CommonAnnots.getCommonAnnots(project, selected);

            if (commData == null) return new JPanel();

            JPanel data = new JPanel(new GridLayout(commData.size(), 1));

            for (String[] item: commData) {

                if (item[1] != null) { //param

                    data.add(new JLabel(item[0] + ": " + item[1]));
                }else{ //no-par
                    data.add(new JLabel(item[0]));
                }
            }
            return data;
        }
    }
}
