package cz.zcu.kiv.annotations.gui;

import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

/**
 * Renderer for JButton included in JTable with attributes of class of
 * edited class
 *
 * @author Filip Markvart
 */
public class TableButtonRenderer implements TableCellRenderer{

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

        JPanel subPanel = new JPanel(new GridLayout(1,1));
        subPanel.add((JButton) value);

        return subPanel;
    }


}
