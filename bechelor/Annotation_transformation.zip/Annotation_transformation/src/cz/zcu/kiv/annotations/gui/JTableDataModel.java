package cz.zcu.kiv.annotations.gui;

import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.table.AbstractTableModel;

/**
 * JTable data model creates a data model for table that contain
 * all classes attributes and shows them in a main Frame/
 *
 * @author Filip Markvart
 */
public class JTableDataModel extends AbstractTableModel{

    private List<JLabel> labels;
    private List<JButton> buttons;

    public JTableDataModel(List<JLabel> attrs, List<JButton> buttons){

        this.buttons = buttons;
        this.labels = attrs;
    }


    public int getRowCount() {
        return labels.size();
    }

    public int getColumnCount() {
        return 1; // 1. column - Name, 2. column Change button
    }

    public Object getValueAt(int rowIndex, int columnIndex) {

        if (columnIndex == 0) {

            return (JLabel) labels.get(rowIndex);
        }else{
            return (JButton) buttons.get(rowIndex);

        }
    }

    @Override
    public Class<?> getColumnClass(int column) {
        return getValueAt(0, column).getClass();
}

   

}
