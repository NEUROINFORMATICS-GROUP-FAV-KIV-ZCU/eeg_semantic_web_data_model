package cz.zcu.kiv.annotations.gui;

import cz.zcu.kiv.annotations.application.IprojectManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;
import javax.swing.JButton;
import cz.zcu.kiv.annotations.application.ProjectManager;
import cz.zcu.kiv.annotations.gui.DisplayProjectData.TableActionListener;
import javax.swing.JLabel;

/**
 *
 * @author Filip Markart
 */
class ButtonChangeListener implements ActionListener{

    private IprojectManager project;

    private Map <String, Map<JLabel, JButton>> guiMap;
    private TableActionListener ListenerDiffs;

    public ButtonChangeListener(IprojectManager project, Map<String, Map<JLabel, JButton>> guiMap, TableActionListener ListenerDiffs) {

        this.project = project;
        this.guiMap = guiMap;
        this.ListenerDiffs = ListenerDiffs;
    }

    public void actionPerformed(ActionEvent e) {
        
        findSource(e.getSource().hashCode());
    }

    private void findSource(int hashCode) {

        for (Map.Entry<String, Map<JLabel, JButton>> classItem: guiMap.entrySet()) {

            for (Map.Entry<JLabel, JButton> attrItem: classItem.getValue().entrySet()) {

                if (attrItem.getValue().hashCode() == hashCode) {
                    
                    if (attrItem.getKey().getText().equals("ParentClass")) { // class annotations
                        
                        DisplayAnnotations displ = new DisplayAnnotations(project, project.getClassesAnnotations(classItem.getKey()), classItem.getKey(), null, ListenerDiffs);
                    }else { // attr annotations
                        DisplayAnnotations displ = new DisplayAnnotations(project, project.getClassesAttrAnnotations(classItem.getKey(),attrItem.getKey().getText()), classItem.getKey(), attrItem.getKey().getText(), ListenerDiffs);
                    }   
                }
            }
        }

    }
}
